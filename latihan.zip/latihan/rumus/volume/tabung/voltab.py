import math
def volume():
    math.pi
    jari_jari = float(input("Masukkan lebar tabung: "))
    tinggi = float(input("Masukkan tinggi tabung: "))
    hasil_volume = math.pi * jari_jari ** 2 * tinggi 
    print(f"Volume tabung dengan jari_jari {jari_jari}, dan tinggi {tinggi} adalah {hasil_volume}")
    return hasil_volume


